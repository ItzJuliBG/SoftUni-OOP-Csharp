﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList() { "dadane", "olele", "lesh sme e"};
            Console.WriteLine(list.RandomString());
        }
    }
}
