﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Cake : Dessert
    {
        public double Calories { get; set; }
        public double CakePrice { get; set; }
        public Cake(string name, decimal price, double grams, double calories) //?r
            : base(name, price, grams)
        {
            Grams = 250;
            Calories = 1000;
            CakePrice = 5;
        }
    }
}
