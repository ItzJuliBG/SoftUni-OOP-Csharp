﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Tea t = new("spiciytea", 22m, 200);

        }
    }
}