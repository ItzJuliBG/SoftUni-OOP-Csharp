﻿using ChristmasPastryShop.Models;
using ChristmasPastryShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Repositories
{
    public class BoothRepository : IRepository<Booth>
    {
        private readonly List<Booth> models;
        public IReadOnlyCollection<Booth> Models => models;

        public void AddModel(Booth model)
        {
           models.Add(model);
        }
    }
}
